package com.xdclass.jvm.sixthChapter;

public class TestJVMFirst {


    private static final int byteSize = 1024*1024;

    public static void main(String[] args) {
        byte[] bytes1 = new byte[2*byteSize];
        byte[] bytes2= new byte[4*byteSize];
        byte[] bytes3 = new byte[5*byteSize];
    }

}
