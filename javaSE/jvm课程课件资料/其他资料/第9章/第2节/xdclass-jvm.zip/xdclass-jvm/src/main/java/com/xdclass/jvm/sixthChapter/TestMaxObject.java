package com.xdclass.jvm.sixthChapter;

public class TestMaxObject {


    public static void main(String[] args) {
        byte[] bytes = new byte[1024*1024*2];
    }
}
